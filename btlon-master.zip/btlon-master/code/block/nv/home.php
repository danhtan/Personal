<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="../../style/home.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <!--   <script type="text/javascript" src="/web/view/js/index.js"></script> -->
</head>
<body>
	<div  style="margin-left: 15px;margin-right: 15px;">
	<div>
		<img src="../../img/anhnen.jpg" style="width:100%;height: 250px;">
		<div class="header">
			<h1>ĐẠI HỌC THỦY LỢI</h1>
			<P style="padding-left: 270px; padding-top: -20px;">Nơi Ươm mầm ước mơ của bạn </P>
		</div>
	</div>
  <!-- <button  id="hahaha">haha</button> -->
<!-- <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand  " href="#"><i class="fa fa-fw fa-home"></i> Home</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="">Trang chủ</a></li>
        <li class="active"><a  href="http://localhost:8080/baitaplon/code/gioithieu.php" style="">Giới Thiệu</a>
        
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#" style="">Quản Lí Sách <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#" id="haha" >Danh Sách sách</a></li>
          <li><a href="#">Thể loại</a></li>
          <li><a href="#" ">Tác Giả</a></li>
        </ul>
      </li>
        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#" style="">QUản LÍ Sách <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#"></a>Thêm sách</li>
          <li><a href="#"></a></li>
          <li><a href="#">Tác Giả</a></li>
        </ul>
      </li>
      <li><a href="#">Page 2</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
 -->

</div>

<!-- <div  class="container" style="margin-top: 0px;" >
<div class="w3-content w3-section" >
	 <img class="mySlides" src="models/img/anh6.jpg" style="width:100% ; height: 345px;">
  <img class="mySlides" src="models/img/anh1.jpg" style="width:100% ; height: 345px;">
  <img class="mySlides" src="models/img/anh2.jpg" style="width:100% ; height: 345px;">
  <img class="mySlides" src="models/img/anh3.jpg" style="width:100%; height: 345px;">
    <img class="mySlides" src="models/img/anh4.jpg" style="width:100%; height: 345px;">
      <img class="mySlides" src="models/img/anh5.jpg" style="width:100%; height: 345px;">
        <img class="mySlides" src="models/img/anh7.jpg" style="width:100%; height: 345px;">
</div>
</div>
 -->

<script>
 // $(document).ready(function(){
  //   $("#sanh").click(function(){
       // $get("block/dssach.php",function(data){$("#indexx").html(data)});
  //      alert("haha");
  //    });
  // });
 // $("#haha").click(function(){
 //   $.get("block/dssach.php",function(data){
 //    $("#indexx").html(data);
 //   })
 //   //alert("ds");
 // });
// var myIndex = 0;
// carousel();
// function carousel(){
//     var i;
//     var x = document.getElementsByClassName("mySlides");
//     for (i = 0; i < x.length; i++) {
//        x[i].style.display = "none";  
//     }
//     myIndex++;
//     if (myIndex > x.length) {myIndex = 1}    
//     x[myIndex-1].style.display = "block";  
//     setTimeout(carousel, 2000); // Change image every 2 seconds
// }

</script>
</div>
</body>
</html>