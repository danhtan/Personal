<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div style="background-color: blue ; text-align: center;">
		<h1><i class="fa fa-graduation-cap" style="font-size:48px;color:red"></i>Thư Viện Đại Học Thủy Lợi</h1>
	</div >
	<div style="background-color: #00e6e6 ; height: 200px;margin: 0px">
		<div style="text-align: center ; padding-top: 60px;">	
		<p>Tòa nhà A45 - 175 Tây Sơn - Đống Đa - Hà Nội</p>
		<p>Điện thoại: 0243.5630971. Email: thuvien@tlu.edu.vn</p>
		<p>Các nội quy của thư viện | Hướng dẫn sử dụng</p>
	</div>

		
	</div>

</body>
</html>