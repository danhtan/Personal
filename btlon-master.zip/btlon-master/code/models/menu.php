<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<!-- <link rel="stylesheet" type="text/css" href="models/stype/home.css"> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <!--   <script type="text/javascript" src="/web/view/js/index.js"></script> -->
</head>
<body>
	<div  style="margin-left: 15px;margin-right: 15px;">
	
  <!-- <button  id="hahaha">haha</button> -->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand  " href="http://localhost:8080/baitaplon/code/index.php"><i class="fa fa-fw fa-home"></i> Home</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Trang chủ</a></li>
        <li class="active"><a  href="http://localhost:8080/baitaplon/code/gioithieu.php" style="">Giới Thiệu</a>
        
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="http://localhost:8080/baitaplon/code/block/dssach.php" style="">Quản Lí Sách <span class="caret"></span></a>
      <!-- <a href="http://localhost:8080/baitaplon/code/block/dssach.php">Quản lí sách</a> -->
        <ul class="dropdown-menu">
          <li><a href="http://localhost:8080/baitaplon/code/block/dssach.php"  >Danh Sách sách</a></li>
          <li><a href="#">Thể loại</a></li>
          <li><a href="#" ">Tác Giả</a></li>
        </ul>
      </li>
        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#" style="">QUản LÍ Sách <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#"></a>Thêm sách</li>
          <li><a href="#"></a></li>
          <li><a href="#">Tác Giả</a></li>
        </ul>
      </li>
      <li><a href="#">Page 2</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>

<div>
	
</div>
</div>
<script>
 // $("#haha").click(function(){
 //   $.get("block/dssach.php",function(data){
 //    $("#indexx").html(data);
 //   })
 //   //alert("ds");
 // });


</script>
</div>
</body>
</html>