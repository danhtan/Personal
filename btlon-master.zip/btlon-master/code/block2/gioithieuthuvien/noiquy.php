<!DOCTYPE html>
<html>
<head>
	<title>	
	</title>
</head>
<body>
	<div  style="margin-left: 20px ;background-color: white;padding: 40px; margin-top: 20px">	
		<h1 style="	color: blue">Nội quy Trung tâm Thông tin – Thư viện</h1>
		<h3>	Điều 1: Quy định chung</h3>
		<p>-	Giờ phục vụ:</p>
		<p>	+ Thứ Hai đến Thứ Sáu: từ 06h30 giờ đến 21h00;</p>
		<p>	+Thứ Bảy và Chủ nhật: từ 07h00 giờ đến 18h00;</p>
		<p>	+ Ngày Lễ, Tết: nghỉ theo qui định;</p>
		<p>	-Sinh viên phải xuất trình thẻ khi vào thư viện;</p>
		<p>	-Không cho người khác mượn và sử dụng thẻ khi vào thư viện;</p>
		<p>	-Giữ gìn trật tự, im lặng, vệ sinh trong thư viện. Không hút thuốc, mang đồ ăn, thức uống, kẹo cao su vào thư viện;</p>
		<p>	-Không mang hung khí, các vật dụng hoặc hóa chất dễ gây cháy nổ vào thư viện. Nghiêm túc thực hiện các quy định về phòng cháy và chữa cháy;</p>
		<p>	-Không cắt xén tranh ảnh, tư liệu, không làm rách và ghi dấu lên sách, báo;</p>
		<p>	-Không mang cặp, túi xách vào kho sách mà phải gửi đúng nơi quy định (tiền, thẻ xe, vật dụng có giá trị sinh viên tự bảo quản, thư viện không chịu trách nhiệm nếu xảy ra mất mát).</p>
		<p>	-Không được mang ra khỏi thư viện: Các tài liệu, sách, báo nếu chưa qua đủ thủ tục mượn; Các vật dụng, trang thiết bị của thư viện nếu chưa được phép của thư viện;</p>
		<p>	-Không tự ý điều chỉnh, tháo gỡ, thay đổi vị trí mọi vật dụng, trang thiết bị tại thư viện;
</p>
<p>	-Không viết, vẽ, ký lên bàn, tường hay bất cứ vật dụng của thư viện;
</p>
<p>	-Thư viện từ chối các sinh viên có dấu hiệu sử dụng rượu, bia hoặc các chất kích thích khác vào thư viện;
</p>
<p>	-Sinh viên tự bảo quản tài sản cá nhân. Thư viện sẽ không chịu trách nhiệm các trường hợp thất lạc hay mất mát tài sản.
</p>
<h3>	Điều 2: Lưu hành tài liệu</h3>
<p>	-Sinh viên mượn/ trả sách phải làm thủ tục tại quầy;
</p>
<p>	-Sách mượn đọc tại chỗ: Mỗi lần mượn tối đa 02 cuốn và không được mang ra khỏi thư viện. Sách mượn tại quầy nào thì trả tại quầy đó. Báo, tạp chí, báo cáo khoa học, đồ án tốt nghiệp, luận văn, luận án, đĩa CD, VCD, DVD chỉ được đọc tại thư viện;
</p>
<p>	-Sách mượn về nhà: Sinh viên mỗi lần được mượn tối đa 04 cuốn sách, sách mượn tại quầy phục vụ ở các kho sách và trả tại quầy lưu hành (tầng trệt). Sách được mượn về nhà miễn phí, nhưng phải đóng tiền thế chân theo giá trị của cuốn sách. Thời gian mượn tối đa 15 ngày và gia hạn 1 lần. Sau thời gian trên nếu bạn đọc chưa trả sách, Thư viện đề nghị Nhà trường sẽ xử lý theo điều 52 Nghị định số 31/2001/NĐ-CP ngày 26/6/2001 về Vi phạm các quy định bảo vệ tài liệu trong thư viện.
</p>
<h3>Điều 3: Truy cập thông tin</h3>
<P>	-Nghiêm cấm việc truy cập, lưu trữ, truyền tải các thông tin bất hợp pháp, có nội dung xấu, đồi trụy hoặc gây hại đến lợi ích quốc gia, ảnh hưởng đến kinh tế, chính trị, văn hóa, xã hội và an ninh quốc phòng;
</P>
<P>	-Tài liệu trong thư viện chỉ dành cho học tập và nghiên cứu, bạn đọc phải tuân thủ theo Luật sở hữu trí tuệ.
</P>
<P>	-Nội quy trên đây nhằm đảm bảo mọi điều kiện thuận tiện cho sinh viên khi đến học tập tại thư viện, đồng thời bảo quản tài sản của nhà trường. Mọi trường hợp vi phạm nội quy sẽ bị xử lý theo quy định.

</P>
	</div>

</body>
</html>