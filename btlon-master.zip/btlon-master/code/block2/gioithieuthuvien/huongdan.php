<!DOCTYPE html>
<html>
<head>
	<title>	</title>
</head>
<body>
	<div style="margin-left: 20px ;background-color: white;padding: 40px; margin-top: 20px">
<h1 style="	color: blue">	Hướng dẫn sử dụng Thư viện</h1>
<p>	<b>1. Thẻ sinh viên</b> cũng là thẻ thư viện. Khi vào thư viện sinh viên nhớ mang theo thẻ để dễ dàng sử dụng các dịch vụ trong thư viện. Khi sử dụng bất kỳ dịch vụ nào của thư viện, sinh viên phải trình thẻ cho cán bộ thư viện.</p>
<h3>	2. Tìm tài liệu:</h3>
<p>	a/ Sinh viên tìm tài liệu trực tiếp trong kho sách tại các tầng lầu:</p>
<p>	- Tầng trệt: Kho sách Kỹ thuật</p>
<p>	- Lầu 2: Kho sách Công nghệ Thông tin, Pháp luật, Ngoại ngữ, Chính  trị – Xã hội, Khoa học Tự nhiên, Kinh tế</p>
<p>	– Lầu 3: Kho sách ngoại văn (chủ yếu là tiếng Anh).</p>
<p>	– Lầu 4: Kho giáo trình, luận văn luận án và kho bài trích tạp chí.</p>
<p>	<b>Lưu ý: </b>Thời gian phục vụ lầu 3 & 4: 07h00 – 16h30.</p>
<h3>	3. Mượn tài liệu:</h3>
<p>	– Sách mượn đọc tại chỗ: Sinh viên làm thủ tục mượn/trả sách tại quầy phục vụ ở mỗi kho sách, mỗi lần mượn 02 cuốn và trả sách trong ngày.</p>
<p>	– Sách mượn về nhà: Sinh viên được mượn sách miễn phí nhưng phải thế chân tiền bằng giá trị cuốn sách. Số lượng mượn từ 1 đến 4 cuốn/1 lần, thời gian tối đa là 15 ngày và gia hạn 1 lần</p>
<h3>	4. Phòng báo và tạp ch</h3>
<p>	Báo và tạp chí được sắp xếp theo chủ đề và nhan đề, sinh viên được tự do chọn báo và tạp chí trên kệ. Khi xem xong các bạn xếp gọn gàng vào đúng vị trí cũ. Ngoài ra, Thư viện có 40.000 bài trích tạp chí nghiên cứu chuyên ngành và lưu trữ tại tầng 4 thư viện. Để xem thông tin bài trích, bạn đọc thực hiện theo hướng dẫn sau:</p>
<h3>	5. Phòng đa phương tiện</h3>
<p>	Thư viện có 10 phòng học nhóm tại lầu 3 và 4. Bạn đọc đăng ký vui lòng liên hệ cán bộ tại Kho sách. Số lượng: tối thiểu 04 người/1 nhóm. Thời gian mượn phòng: tối đa 02 tiếng/1 lượt mượn.</p>
<h3>	7. Mượn giáo trình: </h3>
<p>	 Bạn đọc được mượn giáo trình các khoa (miễn phí) trong 03 tháng tại kho Giáo trình – Luận văn, sách tổng hợp các khoa.</p>

</div>
</body>
</html>