<!DOCTYPE html>
<html>
<head>
	<title>	</title>
</head>
<body>
<div 	style="margin-left: 20px ;background-color: white;padding: 40px; margin-top: 20px">	

	<h1 style="	color: 	blue"	>Chức năng – Nhiệm vụ</h1>
	<h3>1.Chức năng</h3>
	<p>	-Nghiên cứu, ứng dụng thành tựu khoa học công nghệ tiên tiến và công nghệ thông tin vào công tác thông tin – tư liệu, thư viện;</p>
	<p>	-Hợp tác, liên kết trong nước và quốc tế nhằm phát triển hệ thống thông tin – thư viện;</p>
	<p>	-Tổ chức, quản lý nhân sự, tài sản và các sản phẩm, dịch vụ thông tin – thư viện của Trường ĐH Công nghiệp TP. Hồ Chí Minh.</p>
	<p>	-Tổ chức, quản lý nhân sự, tài sản và các sản phẩm, dịch vụ thông tin – thư viện của Trường ĐH Công nghiệp TP. Hồ Chí Minh.</p>
    <h3>Nhiệm vụ</h3>
    <p>	-Trung tâm Thông tin – Thư viện có trách nhiệm tổ chức, quản lý, bổ sung, thu thập, bảo quản các tài liệu sách, báo, tạp chí, băng, đĩa, tài liệu điện tử, luận văn, luận án bảo vệ tại trường, các ấn phẩm của trường và các tài liệu lưu trữ khác, hướng dẫn và bảo vệ tác quyền các tài liệu do Trường quản lý;</p>
    <p>	-Bổ sung, phát triển nguồn tài nguyên thông tin trong nước và nước ngoài;</p>
    <p>	-Tổ chức xử lý kỹ thuật và xử lý thông tin, sắp xếp, lưu trữ, bảo quản, quản lý tài liệu và các nguồn lực thông tin;</p>
    <p>	-Tổ chức phục vụ, hướng dẫn cho cán bộ, giảng viên, sinh viên của trường khai thác, tìm kiếm, sử dụng thuận lợi và có hiệu quả nguồn tài nguyên thông tin;</p>
    <p>	-Hợp tác chặt chẽ với Phòng Quản lý Khoa học và Hợp tác quốc tế, phối hợp với các khoa, phòng, ban chức năng trong trường để hoàn thành tốt nhiệm vụ được giao;</p>
    <p>	-Có kế hoạch đào tạo bồi dưỡng nâng cao trình độ chuyên môn nghiệp vụ, ngoại ngữ, công nghệ thông tin… cho cán bộ thư viện;
</p>
<P>	-Tổ chức, quản lý toàn bộ cơ sở vật chất, trang thiết bị, tài liệu của Trung tâm Thông tin – Thư viện;
</P>
<p>	-Đặt quan hệ hợp tác, giao lưu với các thư viện, trung tâm thông tin trong và ngoài nước để trao đổi tài liệu, kinh nghiệm chuyên môn nghiệp vụ;
</p>
<p>	-Thực hiện báo cáo tình hình hoạt động theo tháng, học kỳ, hàng năm cho Ban Giám hiệu và báo cáo đột xuất khi có yêu cầu của Ban Giám hiệu, Bộ Công Thương, Bộ Giáo dục & Đào tạo, Bộ Văn hóa Thể thao & Du lịch;
</p>
</div>
</body>
</html>