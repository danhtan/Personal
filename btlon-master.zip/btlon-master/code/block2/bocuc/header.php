<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>
		<img src="block2/img/anh3.jpg" style="height: 300px;width: 85% ; margin-left: 100px" >
		
	</div>

</body>
</html>