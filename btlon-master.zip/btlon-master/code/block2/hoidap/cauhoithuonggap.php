<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<!-- <div style="margin-left: 20px ;background-color: white;padding: 40px; margin-top: 20px" >	 -->
	
		<br>
		<div style="clear:both;	">	</div>
		<div id="nd">
			<div style="background-color: #ffdb4d ; padding: 5px">
			<h2>Những Câu Hỏi Thường Gặp</h2>
		</div>

		<h3 style="	color:red">Câu 1: Em làm mất thẻ thư viện thì có được sử dụng Thư viện và được mượn tài liệu của Thư viện không?</h3>
		<p style="	color:blue">	Trả Lời:</p>
		<p>	Nếu em đã làm thủ tục báo mất thẻ, em phải mang theo giấy hẹn ngày lấy thẻ và đọc mã số sinh viên của em để cán bộ Thư viện kiểm tra thông tin về em trong phần mềm Aleph và em vẫn được phục vụ bình thường.</p><br>	

		<h3 style="	color:red">Câu 2: Em muốn biết  thủ tục và thời gian làm lại thẻ sinh viên khi bị mất hoặc hỏng.</h3>
		<p style="	color:blue">	Trả Lời:</p>
		<p>	Khi bị mất thẻ hoặc làm hỏng thẻ em phải làm thủ tục tại Phòng Công tác chính trị & Quản lý sinh viên.   </p><br>	
		<h3 style="	color:red">Câu 3: Em làm mất sách của thư viện thì em phải làm như thế nào?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	Nếu em làm mất hoặc làm hư hỏng tài liệu đã mượn của Thư viện em đến gặp trực tiếp cán bộ trực tại các phòng (Giáo trình, Kho TLTK…) để được hướng dẫn.</p><br>	
		<h3 style="	color:red">Câu 4: Em đã mang trả sách cho Thư viện sao khi kiểm tra account mượn/trả của mình em vẫn thấy còn nợ cuốn sách đó?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	Trên mỗi cuốn sách được gán một mã số (thể hiện bằng mã vạch dán trên bìa sách). Phần mềm Aleph lưu thông tin ngày mượn của em + mã số của cuốn sách. Mặc dù em đã mang trả sách nhưng không đúng mã số của cuốn sách mà em đã mượn. Cuốn sách em đã trả được ghi trả cho một sinh viên khác.

       </p><br>	
       <h3 style="	color:red">Câu 5:  Em cho bạn mượn sách nhưng chưa lấy lại được, giờ em cần cuốn đó để ôn thi. Vậy em có được mượn cuốn đó nữa không?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	Em không mượn được thêm cuốn sách đó. Mỗi sinh viên có thể mượn tối đa 30 cuốn sách trong một học kỳ nhưng không trùng nhau.</p><br>	
		<h3 style="	color:red">Câu 6: Giờ mở cửa và thời gian phục vụ mượn/trả sách của Phòng TLTK?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	  Phòng TLTK và Tạp chí mở cửa từ 7h30 - 17h00 các ngày làm việc trong tuần (từ thứ hai đến thứ sáu). </p><br>	
		<h3 style="	color:red">Câu 7: Em được mượn tài liệu tại Kho TLTK trong thời gian bao lâu? Nếu để quá hạn trả sẽ bị phạt như thế nào?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	Thông thường, sinh viên được mượn 2 cuốn/1 lần, riêng  đối với  sinh viên đang làm đồ án tốt nghiệp được mượn 3 cuốn /1 lần. Thời gian mượn tài liệu là 2 tuần. Nếu có nhu cầu em có thể xin gia hạn thêm bằng các hình thức như: đến Kho TLTK gặp trực tiếp cán bộ thư viện hoặc điện thoại đến số máy (024) 3 8521445 hoặc gửi email đến địa chỉ thuvien@tlu.edu.vn.

</p>
<br>	
<h3 style="	color:red">Câu 8: Những tài liệu nào trong Phòng TLTK không được mượn về?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>	Một số loại hình tài liệu chỉ phục vụ cho tra cứu tại chỗ (không được mượn về), như luận án, từ điển, niên giám, các tài liệu dán tem hồng trên gáy. Nếu có nhu cầu đặc biệt, xin liên hệ với cán bộ trực tại quầy phục vụ.

</p>
<h3 style="	color:red">Câu 9: Cách tìm tài liệu tham khảo trong Phòng TLTK như thế nào?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>Để tìm được tài liệu trong Phòng TLTK, bạn đọc có thể:	</p>
		<br>	
		<p>	1. Chọn tài liệu ngay trên giá: trên đầu các giá sách có bảng ghi ký hiệu môn loại, chủ đề tài liệu theo thứ tự từ trên xuống dưới, từ trái qua phải.</p>
		<br>	
		<p>	2. Tra cứu tài liệu thông qua phần mềm ALEPH bằng cách: vào website của thư viện http:// lib.tlu.edu.vn, chọn mục Tra cứu trực tuyến. Nhập tên sách hoặc tên tác giả cuốn sách vào ô tra cứu và nhấn nút Tìm kiếm. Hệ thống sẽ báo kết quả như: Thư viện có sách hay không, sách nằm ở vị trí nào trên giá, có bao nhiêu bản…

</p>
<br>	
<p>	3. Đề nghị cán bộ thư viện giúp đỡ tìm tài liệu mình cần.</p>
<br>	
<h3 style="	color:red">Câu 10: Em muốn đề xuất bổ sung tài liệu tham khảo trong Kho TLTK có được không?</h3>
		<p style="color:blue">	Trả Lời:</p>
		<p>Thư viện luôn hoan nghênh các ý kiến đóng góp xây dựng. Nếu em muốn đề xuất bổ sung những tài liệu tham khảo cần cho các môn học em có thể viết đề xuất vào sổ “Ghi những đầu sách theo yêu cầu của độc giả” để trên bàn quầy hoặc trao đổi trực tiếp với cán bộ trực.

	</p>
		<br>	



	</div>

	<!-- </div> -->


</body>
</html>