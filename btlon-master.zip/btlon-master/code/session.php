<?php
include("dangnhap.php");
if(isset($_SESSION ['quyen_truy_cap'])){
	$quyen=$_SESSION ['quyen_truy_cap'];
}

?>